
import UIKit

let numbers = [3, 1, 12, 9, 11, 7, 19, 16, 13, 8]

 var maxNumber = numbers.reduce(0) { (res, i) -> Int in
    if res > i {
        return res
    }
    return i
}

print(maxNumber)
